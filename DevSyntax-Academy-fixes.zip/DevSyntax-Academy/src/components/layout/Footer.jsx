import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <p>© {new Date().getFullYear()} DevSyntax Academy</p>
    </footer>
  );
}
